if (typeof(inflationdata) === "undefined") {
    inflationdata = {
        "numbers": {
            "1914": 1.0,
            "1915": 1.0,
            "1916": 7.9,
            "1917": 17.4,
            "1918": 18.0,
            "1919": 14.6,
            "1920": 15.6,
            "1921": -10.5,
            "1922": -6.1,
            "1923": 1.8,
            "1924": 0.0,
            "1925": 2.3,
            "1926": 1.1,
            "1927": -1.7,
            "1928": -1.7,
            "1929": 0.0,
            "1930": -2.3,
            "1931": -9.0,
            "1932": -9.9,
            "1933": -5.1,
            "1934": 3.1,
            "1935": 2.2,
            "1936": 1.5,
            "1937": 3.6,
            "1938": -2.1,
            "1939": -1.4,
            "1940": 0.7,
            "1941": 5.0,
            "1942": 10.9,
            "1943": 6.1,
            "1944": 1.7,
            "1945": 2.3,
            "1946": 8.3,
            "1947": 14.4,
            "1948": 8.1,
            "1949": -1.2,
            "1950": 1.3,
            "1951": 7.9,
            "1952": 1.9,
            "1953": 0.8,
            "1954": 0.7,
            "1955": -0.4,
            "1956": 1.5,
            "1957": 3.3,
            "1958": 2.8,
            "1959": 0.7,
            "1960": 1.7,
            "1961": 1.0,
            "1962": 1.0,
            "1963": 1.3,
            "1964": 1.3,
            "1965": 1.6,
            "1966": 2.9,
            "1967": 3.1,
            "1968": 4.2,
            "1969": 5.5,
            "1970": 5.7,
            "1971": 4.4,
            "1972": 3.2,
            "1973": 6.2,
            "1974": 11.0,
            "1975": 9.1,
            "1976": 5.8,
            "1977": 6.5,
            "1978": 7.6,
            "1979": 11.3,
            "1980": 13.5,
            "1981": 10.3,
            "1982": 6.2,
            "1983": 3.2,
            "1984": 4.3,
            "1985": 3.6,
            "1986": 1.9,
            "1987": 3.6,
            "1988": 4.1,
            "1989": 4.8,
            "1990": 5.4,
            "1991": 4.2,
            "1992": 3.0,
            "1993": 3.0,
            "1994": 2.6,
            "1995": 2.8,
            "1996": 3.0,
            "1997": 2.3,
            "1998": 1.6,
            "1999": 2.2,
            "2000": 3.4,
            "2001": 2.8,
            "2002": 1.6,
            "2003": 2.3,
            "2004": 2.7,
            "2005": 3.4,
            "2006": 3.2,
            "2007": 2.8,
            "2008": 3.8,
            "2009": -0.4,
            "2010": 1.6,
            "2011": 3.2,
            "2012": 2.1,
            "2013": 1.5,
            "2014": 1.6,
            "2015": 0.1,
            "2016": 1.3,
            "2017": 2.1,
            "2018": 2.4,
            "2019": 1.8,
            "2020": 1.2,
            "2021": 4.7,
            "2022": 8.0,
            "2023": 4.1,
            "2024": 2.9
        },

        /**
         * Compute the arithmetic mean of average inflation values.
         * data – an object keyed by year whose values are average inflation rates (number or null).
         * Returns the mean of all numeric averageInflation values.
         */
        computeMean: function() {
            const values = Object.values(inflationdata.numbers).filter(v => typeof v === 'number');
            if (values.length === 0) return null;
            const sum = values.reduce((acc, val) => acc + val, 0);
            return (sum / values.length).toFixed(2);
        },

        /**
         * Compute the population standard deviation of average inflation values.
         * data – an object keyed by year whose values are average inflation rates (number or null).
         * Returns the standard deviation of all numeric averageInflation values.
         */
        computeStdDev: function() {
            const values = Object.values(inflationdata.numbers).filter(v => typeof v === 'number');
            const n = values.length;
            if (n === 0) return null;
            const mean = inflationdata.computeMean(inflationdata.numbers);
            const squaredDiffSum = values.reduce((acc, val) => {
                const diff = val - mean;
                return acc + diff * diff;
            }, 0);
            return Math.sqrt(squaredDiffSum / n).toFixed(2);
        },      


        // === Range-based helpers ===

        /**
         * Returns the max year available in the dataset as a number.
         */
        getMaxYear: function() {
            const years = Object.keys(inflationdata.numbers).map(y => parseInt(y, 10)).filter(Number.isFinite);
            return years.length ? Math.max(...years) : null;
        },

        /**
         * Returns the min year available in the dataset as a number.
         */
        getMinYear: function() {
            const years = Object.keys(inflationdata.numbers).map(y => parseInt(y, 10)).filter(Number.isFinite);
            return years.length ? Math.min(...years) : null;
        },

        /**
         * Compute the mean inflation over an inclusive range [firstYear, lastYear].
         * Non-numeric entries are ignored.
         * Returns a string with 2 decimals (e.g., "3.14").
         */
        computeMeanRange: function(firstYear, lastYear) {
            const a = parseInt(firstYear, 10);
            const b = parseInt(lastYear, 10);
            if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
            const start = Math.min(a, b), end = Math.max(a, b);
            let values = [];
            for (let y = start; y <= end; y++) {
                const v = inflationdata.numbers[String(y)];
                if (typeof v === 'number' && Number.isFinite(v)) values.push(v);
            }
            if (!values.length) return null;
            const sum = values.reduce((acc, val) => acc + val, 0);
            return (sum / values.length).toFixed(2);
        },

        /**
         * Compute the population standard deviation over an inclusive range [firstYear, lastYear].
         * Returns a string with 2 decimals.
         */
        computeStdDevRange: function(firstYear, lastYear) {
            const a = parseInt(firstYear, 10);
            const b = parseInt(lastYear, 10);
            if (!Number.isFinite(a) || !Number.isFinite(b)) return null;
            const start = Math.min(a, b), end = Math.max(a, b);
            let values = [];
            for (let y = start; y <= end; y++) {
                const v = inflationdata.numbers[String(y)];
                if (typeof v === 'number' && Number.isFinite(v)) values.push(v);
            }
            const n = values.length;
            if (!n) return null;
            const mean = values.reduce((acc, v) => acc + v, 0) / n;
            const variance = values.reduce((acc, v) => acc + Math.pow(v - mean, 2), 0) / n;
            return Math.sqrt(variance).toFixed(2);
        }

    }
}
